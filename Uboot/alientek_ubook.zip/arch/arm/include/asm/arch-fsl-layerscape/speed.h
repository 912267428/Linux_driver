/*
 * Copyright 2014-2015, Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _FSL_LAYERSCAPE_SPEED_H
#define _FSL_LAYERSCAPE_SPEED_H
void get_sys_info(struct sys_info *sys_info);
#endif /* _FSL_LAYERSCAPE_SPEED_H */
